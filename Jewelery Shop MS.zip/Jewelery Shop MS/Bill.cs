﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jewelery_Shop_MS
{
    public partial class Bill : Form
    {
        public Bill()
        {
            InitializeComponent();
            DisplayBill();
            GetCusId();
            Displayproduct();
        }


         SqlConnection Con = new SqlConnection(connectionString: @"Data Source=Kirti\SQLEXPRESS;Initial Catalog=""Jewellery Shop MS"";Integrated Security=True");
        private void DisplayBill()
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=Kirti\SQLEXPRESS;Initial Catalog=""Jewellery Shop MS"";Integrated Security=True"))
            {
                string Query = "SELECT * FROM User_Bill";

                SqlDataAdapter adapter = new SqlDataAdapter(Query, con);
                SqlCommandBuilder scb = new SqlCommandBuilder(adapter);
                var ds = new DataSet();

                adapter.Fill(ds);
                BillDgv.DataSource = ds.Tables[0];
            }
        }
        private void Displayproduct()
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=Kirti\SQLEXPRESS;Initial Catalog=""Jewellery Shop MS"";Integrated Security=True"))
            {
                string Query = "SELECT * FROM User_Pro";
                SqlDataAdapter adapter = new SqlDataAdapter(Query, con);
                SqlCommandBuilder scb = new SqlCommandBuilder(adapter);
                var ds = new DataSet();

                adapter.Fill(ds);
                ProductDgv.DataSource = ds.Tables[0];
            }
        }
        private void GetCusId()
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=Kirti\SQLEXPRESS;Initial Catalog=""Jewellery Shop MS"";Integrated Security=True"))
            {
                con.Open();
                string query = "SELECT CusId FROM User_Cus";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                // Create a DataTable to store customer IDs
                DataTable dt = new DataTable();
                dt.Load(reader);

                // Bind the customer IDs to the combo box
                CusIdCb.DisplayMember = "CusId";
                CusIdCb.DataSource = dt;
            }
        }

        void DisplayCusName()
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=Kirti\SQLEXPRESS;Initial Catalog=""Jewellery Shop MS"";Integrated Security=True"))
            {
                con.Open();
                string selectedCustomerId = CusIdCb.Text;

                string query = "SELECT CusName FROM User_Cus WHERE CusId = @CustomerId";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@CustomerId", selectedCustomerId);

                object result = cmd.ExecuteScalar();

                if (result != null)
                {
                    // Display the customer name in the appropriate TextBox or control
                    CusNameTb.Text = result.ToString();
                }
                else
                {
                    // Handle the case where the customer with the selected ID is not found
                    CusNameTb.Text = "Customer Not Found";
                }
            }
        }





        private void ProNameCb_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=Kirti\SQLEXPRESS;Initial Catalog=""Jewellery Shop MS"";Integrated Security=True"))
            {
                con.Open();
                // Assuming you have a table named 'Products' with columns 'ProductName' and 'UnitPrice'
                string query = "SELECT UnitPrice FROM User_Pro WHERE ProName = @ProductName";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@ProductName", ProNameCb.Text);

                // Execute the query and fetch the unit price
                object result = cmd.ExecuteScalar();
                if (result != null)
                {
                    // Display the unit price in the UPTb text box
                    UPTb.Text = result.ToString();
                }
                else
                {
                    // Handle the case where the product is not found
                    UPTb.Text = "0"; // Or display an error message
                }
            }
        }


        private void CrossBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {
            BillIdTb.Text = "";
            ProNameCb.Text = "";
            CusIdCb.Text = "";
            CusNameTb.Text = "";
            ProQuanTb.Text = "";
            UPTb.Text = "";
            TPTb.Text = "";
        }

        

        

        private void ProQuanTb_TextChanged(object sender, EventArgs e)
        {
            try
            {
                // Parse the product quantity and unit price to calculate total amount
                if (int.TryParse(ProQuanTb.Text, out int quantity) && int.TryParse(UPTb.Text, out int unitPrice))
                {
                    // Calculate total amount
                    int totalAmount = quantity * unitPrice;

                    // Display total amount in the TPTb text box
                    TPTb.Text = totalAmount.ToString();
                }
                else
                {
                    // Handle the case where product quantity or unit price is not a valid integer
                    TPTb.Text = "0"; // Or display an error message
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CusIdCb_SelectedIndexChanged(object sender, EventArgs e)
        {
            DisplayCusName();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {
              
        }

       
        int flag = 0;
        int stock;
        int sum;
        private void Addbtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(BillIdTb.Text) || string.IsNullOrWhiteSpace(ProQuanTb.Text) || string.IsNullOrWhiteSpace(TPTb.Text))
            {
                MessageBox.Show("Missing Information");
                return;
            }

            // Calculate total
            if (int.TryParse(ProQuanTb.Text, out int quantity) && int.TryParse(UPTb.Text, out int unitPrice))
            {
                int total = quantity * unitPrice;
                sum += total;
                TPTb.Text = sum.ToString();

                // Insert data into the User_Bill table
                using (SqlConnection Con = new SqlConnection(connectionString: @"Data Source=Kirti\SQLEXPRESS;Initial Catalog=Jewellery Shop MS;Integrated Security=True"))
                {
                    Con.Open();
                    string query = "INSERT INTO User_Bill VALUES (@BillId, @ProductName, @CustomerId, @CustomerName, @ProductQuantity, @TotalPrice, @UnitPrice)";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.Parameters.AddWithValue("@BillId", BillIdTb.Text);
                    cmd.Parameters.AddWithValue("@ProductName", ProNameCb.Text);
                    cmd.Parameters.AddWithValue("@CustomerId", CusIdCb.Text);
                    cmd.Parameters.AddWithValue("@CustomerName", CusNameTb.Text);
                    cmd.Parameters.AddWithValue("@ProductQuantity", ProQuanTb.Text);
                    cmd.Parameters.AddWithValue("@TotalPrice", TPTb.Text);
                    cmd.Parameters.AddWithValue("@UnitPrice", UPTb.Text);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Record Entered Successfully");
                    Con.Close();
                    DisplayBill();
                }
            }
            else
            {
                MessageBox.Show("Invalid Quantity or Unit Price");
            }

        }
        //void UpdateProduct()
        //{
        //    try
        //    {
        //        string id = ProductDgv.SelectedRows[0].Cells[0].Value.ToString();
        //        int Qty = stock = Convert.ToInt32(ProQuanTb.Text);
        //        if (Qty < 0)
        //        {
        //            MessageBox.Show("Operation Failed");
        //        }
        //        else 
        //        {
        //            Con.Open();
        //            string query = "Update Product set Quantity = '"+ Qty +"',Where ProId= '"+id+"';";
        //            SqlCommand cmd = new SqlCommand(query, Con);
        //            cmd.ExecuteNonQuery();
        //            Con.Close();
                   
        //            Displayproduct();
                    
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //    finally
        //    {
        //        Con.Close();
        //    }
        //}

       

        private void Customerlbl_Click(object sender, EventArgs e)
        {

            Customer obj = new Customer();
            obj.Show();
            this.Hide();
        }

        private void Productlbl_Click(object sender, EventArgs e)
        {
            Product obj = new Product();
            obj.Show();
            this.Hide();
        }

        private void Logoutlbl_Click(object sender, EventArgs e)
        {

            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void Deletebtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(BillIdTb.Text))
            {
                MessageBox.Show("Missing Information");
                return;
            }

            // Delete record from the User_Bill table
            using (SqlConnection Con = new SqlConnection(connectionString: @"Data Source=Kirti\SQLEXPRESS;Initial Catalog=Jewellery Shop MS;Integrated Security=True"))
            {
                Con.Open();
                string query = "DELETE FROM User_Bill WHERE BillId = @BillId";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.Parameters.AddWithValue("@BillId", BillIdTb.Text);

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Record Deleted Successfully");
                }
                else
                {
                    MessageBox.Show("Record not found");
                }

                Con.Close();
                DisplayBill();
            }
        }

        private void Updatebtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(BillIdTb.Text) || string.IsNullOrWhiteSpace(ProNameCb.Text) ||
         string.IsNullOrWhiteSpace(CusIdCb.Text) || string.IsNullOrWhiteSpace(CusNameTb.Text) ||
         string.IsNullOrWhiteSpace(ProQuanTb.Text) || string.IsNullOrWhiteSpace(UPTb.Text) ||
         string.IsNullOrWhiteSpace(TPTb.Text))
            {
                MessageBox.Show("Missing Information");
                return;
            }

            // Update record in the User_Bill table
            using (SqlConnection Con = new SqlConnection(connectionString: @"Data Source=Kirti\SQLEXPRESS;Initial Catalog=Jewellery Shop MS;Integrated Security=True"))
            {
                Con.Open();

                int quantity = Convert.ToInt32(ProQuanTb.Text);
                int unitPrice = Convert.ToInt32(UPTb.Text);
                int total = quantity * unitPrice;

                string query = "UPDATE User_Bill SET Product=@PN, CusId=@CI, CusName=@CN, Quantity=@PQ, u_price=@UP, Total=@TP WHERE BillId=@BI";

                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.Parameters.AddWithValue("@BI", BillIdTb.Text);
                cmd.Parameters.AddWithValue("@PN", ProNameCb.Text);
                cmd.Parameters.AddWithValue("@CI", CusIdCb.Text);
                cmd.Parameters.AddWithValue("@CN", CusNameTb.Text);
                cmd.Parameters.AddWithValue("@PQ", ProQuanTb.Text);
                cmd.Parameters.AddWithValue("@UP", UPTb.Text);
                cmd.Parameters.AddWithValue("@TP", total);

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Record Updated Successfully");
                }
                else
                {
                    MessageBox.Show("Record not found");
                }

                Con.Close();
                DisplayBill();
            }
        }

      

      

        private void Billlbl_Click(object sender, EventArgs e)
        {
            this.Hide();
            Bill obj = new Bill();
            obj.Show();
            
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void BillDgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = BillDgv.Rows[e.RowIndex];

                    // Populate the TextBoxes and ComboBox with the clicked row's data
                    BillIdTb.Text = row.Cells["BillId"].Value.ToString();
                    ProNameCb.Text = row.Cells["Product"].Value.ToString();
                    CusIdCb.Text = row.Cells["CusId"].Value.ToString();
                    CusNameTb.Text = row.Cells["CusName"].Value.ToString();
                    ProQuanTb.Text = row.Cells["Quantity"].Value.ToString();
                    UPTb.Text = row.Cells["u_price"].Value.ToString();
                    TPTb.Text = row.Cells["Total"].Value.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BillDgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
