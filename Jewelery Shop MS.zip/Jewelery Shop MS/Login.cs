﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jewelery_Shop_MS
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();

            PasswordTb.UseSystemPasswordChar = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //PasswordTb.UseSystemPasswordChar = true;
        }

        private void CrossBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void RestBtn_Click(object sender, EventArgs e)
        {
            UNameTb.Text = "";
            PasswordTb.Text = "";
        }

        private void LogBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (UNameTb.Text == "" && PasswordTb.Text == "")
                {
                    MessageBox.Show("Missing Information");
                }

                else if (UNameTb.Text == "Kirti" && PasswordTb.Text == "kirti27")
                {
                    MessageBox.Show("Login Successfully");
                    this.Hide();
                    Customer obj =  new Customer();
                   obj.Show();
                    
                }
                else
                {
                    MessageBox.Show("Please Enter The Correct Username and Password");
                }
                }
                catch (Exception )
                    {
                    MessageBox.Show("ex.Message");
                }

            }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1_Show_Hide.Checked)
            {
                PasswordTb.UseSystemPasswordChar = false;
            }
            else
            {
                PasswordTb.UseSystemPasswordChar = true;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void UNameTb_TextChanged(object sender, EventArgs e)
        {
             
        }

        private void PasswordTb_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }
