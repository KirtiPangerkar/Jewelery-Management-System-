﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jewelery_Shop_MS
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
            DisplayCustomer();
            CustomerDgv.CellClick += CustomerDgv_CellClick;
        }
        readonly SqlConnection Con = new SqlConnection(connectionString: @"Data Source=Kirti\SQLEXPRESS;Initial Catalog=""Jewellery Shop MS"";Integrated Security=True");
        private void DisplayCustomer()
        {
            try
            {
                Con.Open();
                string Query = "select * from User_Cus";
                SqlDataAdapter adapter = new SqlDataAdapter(Query, Con);
                SqlCommandBuilder scb = new SqlCommandBuilder(adapter);
                var ds = new DataSet();
                adapter.Fill(ds);
                CustomerDgv.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Con.Close();
            }
        }


       

        private void CrossBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {
            CusIdTb.Text = "";
            CusNameTb.Text = "";
            CusPhoneTb.Text = "";
        }

        private void Productlbl_Click(object sender, EventArgs e)
        {

            Product obj = new Product();
            obj.Show();
            this.Hide();

        }

        private void LogBtn_Click(object sender, EventArgs e)
        {
            if (CusIdTb.Text == "" || CusNameTb.Text == "" || CusPhoneTb.Text == "")
            {
                MessageBox.Show("Missing Information");
                return;
            }

            Con.Open();
            string query = "SELECT COUNT(*) FROM User_Cus WHERE CusId=@CusId";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.Parameters.AddWithValue("@CusId", CusIdTb.Text);

            int count = (int)cmd.ExecuteScalar();

            if (count > 0)
            {
                MessageBox.Show("Customer ID already exists. Use the Update button to modify existing records.");
                Con.Close();
            }
            else
            {
                // Customer ID doesn't exist, so insert a new record
                query = "INSERT INTO User_Cus (CusId, CusName, CusPhone) VALUES (@CusId, @CN, @CP)";
                cmd = new SqlCommand(query, Con);
                cmd.Parameters.AddWithValue("@CusId", CusIdTb.Text);
                cmd.Parameters.AddWithValue("@CN", CusNameTb.Text);
                cmd.Parameters.AddWithValue("@CP", CusPhoneTb.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Entered Successfully");
                Con.Close();
                // Call DisplayCustomer() to update the DataGridView
                DisplayCustomer();
                CusIdTb.Text = "";
                CusNameTb.Text = "";
                CusPhoneTb.Text = "";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                if (CusIdTb.Text == "" || CusNameTb.Text == "" || CusPhoneTb.Text == "")
                {
                    MessageBox.Show("Missing Information");
                }
                else
                {
                    Con.Open();
                    string query = "UPDATE User_Cus SET CusName=@CN, CusPhone=@CP WHERE CusId=@CusId";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.Parameters.AddWithValue("@CusId", CusIdTb.Text);
                    cmd.Parameters.AddWithValue("@CN", CusNameTb.Text);
                    cmd.Parameters.AddWithValue("@CP", CusPhoneTb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Updated Successfully");
                    Con.Close();
                    DisplayCustomer();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (Con.State == ConnectionState.Open)
                {
                    Con.Close();
                }
            }
        } 


            private void DelBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (CusIdTb.Text == "")
                {
                    MessageBox.Show("Please enter Customer ID to delete the record.");
                }
                else
                {
                    Con.Open();
                    string query = "DELETE FROM User_Cus WHERE CusId=@CI";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.Parameters.AddWithValue("@CI", CusIdTb.Text);
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Record Deleted Successfully");
                        Con.Close();
                        DisplayCustomer(); // Refresh the DataGridView after deletion
                        CusIdTb.Text = "";
                        CusNameTb.Text = "";
                        CusPhoneTb.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("No record found with the provided Customer ID");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (Con.State == ConnectionState.Open)
                {
                    Con.Close();
                }
            }
        }

       

       
        private void Billlbl_Click(object sender, EventArgs e)
        {
            Bill obj = new Bill();
            obj.Show();
            this.Hide();
        }

       

        private void button1_Click_1(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void CustomerDgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = CustomerDgv.Rows[e.RowIndex];

                // Populate your textboxes or perform any action based on the selected row data
                CusIdTb.Text = row.Cells["CusId"].Value.ToString();
                CusNameTb.Text = row.Cells["CusName"].Value.ToString();
                CusPhoneTb.Text = row.Cells["CusPhone"].Value.ToString();
            }
        }

        private void CustomerDgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
