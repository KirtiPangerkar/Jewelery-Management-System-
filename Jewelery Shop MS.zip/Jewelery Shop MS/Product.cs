﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jewelery_Shop_MS
{
    public partial class Product : Form
    {
        public Product()
        {
            InitializeComponent();
            DisplayProduct();
        }
        readonly SqlConnection Con = new SqlConnection(connectionString: @"Data Source=Kirti\SQLEXPRESS;Initial Catalog=""Jewellery Shop MS"";Integrated Security=True");
        private void DisplayProduct()
        {
            try
            {
                Con.Open();
                string Query = "select * from User_Pro";
                SqlDataAdapter adapter = new SqlDataAdapter(Query, Con);
                SqlCommandBuilder scb = new SqlCommandBuilder(adapter);
                var ds = new DataSet();
                adapter.Fill(ds);
                ProductDgv.DataSource = ds.Tables[0];
                Con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Con.Close();
            }
        }
        private void CrossBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {
            ProIdTb.Text = "";
            ProNameCb.Text = "";
            ProCatCb.Text = "";
            ProQuanTb.Text = "";
            UPTb.Text = ""; 
        }

        private void LogBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (ProIdTb.Text == "" || ProNameCb.Text == "" || ProCatCb.Text == "" || ProQuanTb.Text == "" || UPTb.Text == "")
                {
                    MessageBox.Show("Missing Information");
                }
                else
                {
                    Con.Open();
                    string query = "insert into [User_Pro] values('" + ProIdTb.Text + "','" + ProNameCb.Text + "','" + ProCatCb.Text + "','" + ProQuanTb.Text + "','" + UPTb.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    Con.Close();
                    MessageBox.Show("Record Entered Successfully");
                    DisplayProduct();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Con.Close();
            }
        }

        private void Update_btn_Click(object sender, EventArgs e)
        {
            try
            {
                if (ProIdTb.Text == "" || ProNameCb.Text == "" || ProCatCb.Text == "" || ProQuanTb.Text == "" || UPTb.Text == "")
                {
                    MessageBox.Show("Missing Information");
                }
                else
                {
                    Con.Open();
                    string query = "UPDATE User_Pro SET ProName=@PN, ProCategory=@PC, Quantity=@Q, UnitPrice=@UP WHERE ProId=@PI";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.Parameters.AddWithValue("@PI", ProIdTb.Text);
                    cmd.Parameters.AddWithValue("@PN", ProNameCb.Text);
                    cmd.Parameters.AddWithValue("@Pc", ProCatCb.Text);
                    cmd.Parameters.AddWithValue("@Q", ProQuanTb.Text);
                    cmd.Parameters.AddWithValue("@UP", UPTb.Text);
                    cmd.ExecuteNonQuery();
                    Con.Close();
                    MessageBox.Show("Record UPdated Successfully");
                    DisplayProduct();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally 
            {
                Con.Close();
            }
            }

        private void DelBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (ProIdTb.Text == "")
                {
                    MessageBox.Show("Missing Information");
                }
                else
                {
                    Con.Open();
                    string query = "delete from User_Pro where ProId= '" + ProIdTb.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    Con.Close();
                    MessageBox.Show("Record Deleted Successfully");
                    DisplayProduct();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Con.Close();
            }
        }

        private void ProductDgv_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                ProIdTb.Text = ProductDgv.SelectedRows[0].Cells[0].Value.ToString();
                ProNameCb.Text = ProductDgv.SelectedRows[0].Cells[1].Value.ToString();
                ProCatCb.Text = ProductDgv.SelectedRows[0].Cells[2].Value.ToString();
                ProQuanTb.Text = ProductDgv.SelectedRows[0].Cells[3].Value.ToString();
                UPTb.Text = ProductDgv.SelectedRows[0].Cells[4].Value.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Con.Close();
            }
        }

        private void Product_Load(object sender, EventArgs e)
        {
            ProductDgv.ColumnHeadersDefaultCellStyle.BackColor = Color.Black;
            ProductDgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            ProductDgv.RowsDefaultCellStyle.BackColor = Color.Black;
            ProductDgv.BackgroundColor = Color.Black;
            ProductDgv.ForeColor = Color.White;
            ProductDgv.RowsDefaultCellStyle.SelectionForeColor = Color.Black;
            ProductDgv.RowsDefaultCellStyle.SelectionBackColor = Color.Yellow;
            ProductDgv.RowHeadersDefaultCellStyle.BackColor = Color.Black;
        }

        private void ProductDgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void Customerlbl_Click(object sender, EventArgs e)
        {
            Customer obj = new Customer();
            obj.Show();
            this.Hide();
        }

        private void Billlbl_Click(object sender, EventArgs e)
        {
            Bill obj = new Bill();
            obj.Show();
            this.Hide();
        }

        private void Logoutlbl_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void ProductDgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = ProductDgv.Rows[e.RowIndex];

                    // Populate the TextBoxes and ComboBox with the clicked row's data
                    ProIdTb.Text = row.Cells["ProId"].Value.ToString();
                    ProNameCb.Text = row.Cells["ProName"].Value.ToString();
                    ProCatCb.Text = row.Cells["ProCategory"].Value.ToString();
                    ProQuanTb.Text = row.Cells["Quantity"].Value.ToString();
                    UPTb.Text = row.Cells["UnitPrice"].Value.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        
    }

        private void ProductDgv_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
