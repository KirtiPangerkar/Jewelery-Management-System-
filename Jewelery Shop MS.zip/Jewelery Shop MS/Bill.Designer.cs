﻿namespace Jewelery_Shop_MS
{
    partial class Bill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bill));
            this.panel3 = new System.Windows.Forms.Panel();
            this.UPTb = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.CusNameTb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.CusIdCb = new System.Windows.Forms.ComboBox();
            this.ProNameCb = new System.Windows.Forms.ComboBox();
            this.TPTb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ProQuanTb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.BillIdTb = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.Billlbl = new System.Windows.Forms.Label();
            this.Productlbl = new System.Windows.Forms.Label();
            this.Customerlbl = new System.Windows.Forms.Label();
            this.CrossBtn = new System.Windows.Forms.Button();
            this.Addbtn = new System.Windows.Forms.Button();
            this.ResetBtn = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.Updatebtn = new System.Windows.Forms.Button();
            this.Deletebtn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BillDgv = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ProductDgv = new System.Windows.Forms.DataGridView();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BillDgv)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ProductDgv)).BeginInit();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel3.Controls.Add(this.UPTb);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.CusNameTb);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.CusIdCb);
            this.panel3.Controls.Add(this.ProNameCb);
            this.panel3.Controls.Add(this.TPTb);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.ProQuanTb);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.BillIdTb);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(-20, -12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(312, 671);
            this.panel3.TabIndex = 13;
            // 
            // UPTb
            // 
            this.UPTb.Location = new System.Drawing.Point(25, 611);
            this.UPTb.Name = "UPTb";
            this.UPTb.Size = new System.Drawing.Size(227, 22);
            this.UPTb.TabIndex = 31;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(30, 571);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(167, 31);
            this.label5.TabIndex = 30;
            this.label5.Text = "Unit Price";
            // 
            // CusNameTb
            // 
            this.CusNameTb.Location = new System.Drawing.Point(25, 358);
            this.CusNameTb.Name = "CusNameTb";
            this.CusNameTb.Size = new System.Drawing.Size(227, 22);
            this.CusNameTb.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(19, 324);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(246, 31);
            this.label4.TabIndex = 28;
            this.label4.Text = "Customer Name";
            // 
            // CusIdCb
            // 
            this.CusIdCb.FormattingEnabled = true;
            this.CusIdCb.Location = new System.Drawing.Point(25, 279);
            this.CusIdCb.Name = "CusIdCb";
            this.CusIdCb.Size = new System.Drawing.Size(227, 24);
            this.CusIdCb.TabIndex = 27;
            this.CusIdCb.SelectedIndexChanged += new System.EventHandler(this.CusIdCb_SelectedIndexChanged);
            // 
            // ProNameCb
            // 
            this.ProNameCb.FormattingEnabled = true;
            this.ProNameCb.Items.AddRange(new object[] {
            "Diamond Engagement Ring",
            "Pearl Necklase",
            "Statement Earrings",
            "Men\'s Leather Bracelet",
            "Vintage Brooch",
            "Ethic Beaded Necklace"});
            this.ProNameCb.Location = new System.Drawing.Point(25, 190);
            this.ProNameCb.Name = "ProNameCb";
            this.ProNameCb.Size = new System.Drawing.Size(227, 24);
            this.ProNameCb.TabIndex = 26;
            this.ProNameCb.SelectedIndexChanged += new System.EventHandler(this.ProNameCb_SelectedIndexChanged);
            // 
            // TPTb
            // 
            this.TPTb.Location = new System.Drawing.Point(25, 529);
            this.TPTb.Name = "TPTb";
            this.TPTb.Size = new System.Drawing.Size(227, 22);
            this.TPTb.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(25, 495);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(194, 31);
            this.label3.TabIndex = 21;
            this.label3.Text = "Total Price";
            // 
            // ProQuanTb
            // 
            this.ProQuanTb.Location = new System.Drawing.Point(25, 448);
            this.ProQuanTb.Name = "ProQuanTb";
            this.ProQuanTb.Size = new System.Drawing.Size(227, 22);
            this.ProQuanTb.TabIndex = 20;
            this.ProQuanTb.TextChanged += new System.EventHandler(this.ProQuanTb_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(25, 414);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(287, 31);
            this.label2.TabIndex = 19;
            this.label2.Text = "Product Quantity";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(25, 252);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(195, 62);
            this.label9.TabIndex = 17;
            this.label9.Text = "Customer Id\r\n\r\n";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(33, 156);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(139, 31);
            this.label8.TabIndex = 16;
            this.label8.Text = "Product";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // BillIdTb
            // 
            this.BillIdTb.Location = new System.Drawing.Point(25, 110);
            this.BillIdTb.Name = "BillIdTb";
            this.BillIdTb.Size = new System.Drawing.Size(227, 22);
            this.BillIdTb.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(30, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 31);
            this.label6.TabIndex = 13;
            this.label6.Text = "Bill  Id";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(111, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 31);
            this.label7.TabIndex = 14;
            this.label7.Text = "Bill";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(671, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(256, 31);
            this.label1.TabIndex = 28;
            this.label1.Text = "JEWELLERY SHOP";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gray;
            this.panel4.Controls.Add(this.button1);
            this.panel4.Controls.Add(this.Billlbl);
            this.panel4.Controls.Add(this.Productlbl);
            this.panel4.Controls.Add(this.Customerlbl);
            this.panel4.Location = new System.Drawing.Point(308, 40);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1022, 64);
            this.panel4.TabIndex = 29;
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(968, 14);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(44, 41);
            this.button1.TabIndex = 15;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Billlbl
            // 
            this.Billlbl.AutoSize = true;
            this.Billlbl.BackColor = System.Drawing.Color.Crimson;
            this.Billlbl.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Billlbl.ForeColor = System.Drawing.Color.Black;
            this.Billlbl.Location = new System.Drawing.Point(651, 14);
            this.Billlbl.Name = "Billlbl";
            this.Billlbl.Size = new System.Drawing.Size(75, 31);
            this.Billlbl.TabIndex = 13;
            this.Billlbl.Text = "Bill";
            this.Billlbl.Click += new System.EventHandler(this.Billlbl_Click);
            // 
            // Productlbl
            // 
            this.Productlbl.AutoSize = true;
            this.Productlbl.BackColor = System.Drawing.Color.Crimson;
            this.Productlbl.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Productlbl.ForeColor = System.Drawing.Color.Black;
            this.Productlbl.Location = new System.Drawing.Point(327, 15);
            this.Productlbl.Name = "Productlbl";
            this.Productlbl.Size = new System.Drawing.Size(139, 31);
            this.Productlbl.TabIndex = 12;
            this.Productlbl.Text = "Product";
            this.Productlbl.Click += new System.EventHandler(this.Productlbl_Click);
            // 
            // Customerlbl
            // 
            this.Customerlbl.AutoSize = true;
            this.Customerlbl.BackColor = System.Drawing.Color.Crimson;
            this.Customerlbl.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Customerlbl.ForeColor = System.Drawing.Color.Black;
            this.Customerlbl.Location = new System.Drawing.Point(13, 15);
            this.Customerlbl.Name = "Customerlbl";
            this.Customerlbl.Size = new System.Drawing.Size(159, 31);
            this.Customerlbl.TabIndex = 12;
            this.Customerlbl.Text = "Customer";
            this.Customerlbl.Click += new System.EventHandler(this.Customerlbl_Click);
            // 
            // CrossBtn
            // 
            this.CrossBtn.BackColor = System.Drawing.Color.DarkGray;
            this.CrossBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CrossBtn.Font = new System.Drawing.Font("Algerian", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CrossBtn.ForeColor = System.Drawing.Color.Black;
            this.CrossBtn.Location = new System.Drawing.Point(1298, -3);
            this.CrossBtn.Name = "CrossBtn";
            this.CrossBtn.Size = new System.Drawing.Size(32, 31);
            this.CrossBtn.TabIndex = 15;
            this.CrossBtn.Text = "X";
            this.CrossBtn.UseVisualStyleBackColor = false;
            this.CrossBtn.Click += new System.EventHandler(this.CrossBtn_Click);
            // 
            // Addbtn
            // 
            this.Addbtn.BackColor = System.Drawing.Color.White;
            this.Addbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addbtn.Font = new System.Drawing.Font("Mongolian Baiti", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addbtn.ForeColor = System.Drawing.Color.Black;
            this.Addbtn.Location = new System.Drawing.Point(364, 368);
            this.Addbtn.Name = "Addbtn";
            this.Addbtn.Size = new System.Drawing.Size(129, 31);
            this.Addbtn.TabIndex = 31;
            this.Addbtn.Text = "Add";
            this.Addbtn.UseVisualStyleBackColor = false;
            this.Addbtn.Click += new System.EventHandler(this.Addbtn_Click);
            // 
            // ResetBtn
            // 
            this.ResetBtn.BackColor = System.Drawing.Color.White;
            this.ResetBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ResetBtn.Font = new System.Drawing.Font("Mongolian Baiti", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResetBtn.ForeColor = System.Drawing.Color.Black;
            this.ResetBtn.Location = new System.Drawing.Point(583, 368);
            this.ResetBtn.Name = "ResetBtn";
            this.ResetBtn.Size = new System.Drawing.Size(125, 31);
            this.ResetBtn.TabIndex = 34;
            this.ResetBtn.Text = "Reset";
            this.ResetBtn.UseVisualStyleBackColor = false;
            this.ResetBtn.Click += new System.EventHandler(this.ResetBtn_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(783, 110);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 31);
            this.label10.TabIndex = 15;
            this.label10.Text = "Bill";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(753, 402);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(139, 31);
            this.label11.TabIndex = 36;
            this.label11.Text = "Product";
            // 
            // Updatebtn
            // 
            this.Updatebtn.BackColor = System.Drawing.Color.White;
            this.Updatebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Updatebtn.Font = new System.Drawing.Font("Mongolian Baiti", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatebtn.ForeColor = System.Drawing.Color.Black;
            this.Updatebtn.Location = new System.Drawing.Point(823, 368);
            this.Updatebtn.Name = "Updatebtn";
            this.Updatebtn.Size = new System.Drawing.Size(114, 31);
            this.Updatebtn.TabIndex = 37;
            this.Updatebtn.Text = "Update";
            this.Updatebtn.UseVisualStyleBackColor = false;
            this.Updatebtn.Click += new System.EventHandler(this.Updatebtn_Click);
            // 
            // Deletebtn
            // 
            this.Deletebtn.BackColor = System.Drawing.Color.White;
            this.Deletebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Deletebtn.Font = new System.Drawing.Font("Mongolian Baiti", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebtn.ForeColor = System.Drawing.Color.Black;
            this.Deletebtn.Location = new System.Drawing.Point(1035, 368);
            this.Deletebtn.Name = "Deletebtn";
            this.Deletebtn.Size = new System.Drawing.Size(108, 31);
            this.Deletebtn.TabIndex = 38;
            this.Deletebtn.Text = "Delete";
            this.Deletebtn.UseVisualStyleBackColor = false;
            this.Deletebtn.Click += new System.EventHandler(this.Deletebtn_Click);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.AutoSize = true;
            this.panel1.Controls.Add(this.BillDgv);
            this.panel1.Location = new System.Drawing.Point(298, 144);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1014, 218);
            this.panel1.TabIndex = 39;
            // 
            // BillDgv
            // 
            this.BillDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.BillDgv.Location = new System.Drawing.Point(29, 17);
            this.BillDgv.Name = "BillDgv";
            this.BillDgv.RowHeadersWidth = 51;
            this.BillDgv.RowTemplate.Height = 24;
            this.BillDgv.Size = new System.Drawing.Size(835, 182);
            this.BillDgv.TabIndex = 0;
            this.BillDgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.BillDgv_CellClick);
            this.BillDgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.BillDgv_CellContentClick);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.ProductDgv);
            this.panel2.Location = new System.Drawing.Point(327, 436);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(835, 185);
            this.panel2.TabIndex = 40;
            // 
            // ProductDgv
            // 
            this.ProductDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ProductDgv.Location = new System.Drawing.Point(20, 17);
            this.ProductDgv.Name = "ProductDgv";
            this.ProductDgv.RowHeadersWidth = 51;
            this.ProductDgv.RowTemplate.Height = 24;
            this.ProductDgv.Size = new System.Drawing.Size(796, 156);
            this.ProductDgv.TabIndex = 0;
            // 
            // Bill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(1332, 660);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Deletebtn);
            this.Controls.Add(this.Updatebtn);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.CrossBtn);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.ResetBtn);
            this.Controls.Add(this.Addbtn);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel3);
            this.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Bill";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bill";
            this.Shown += new System.EventHandler(this.CusIdCb_SelectedIndexChanged);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BillDgv)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ProductDgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox CusIdCb;
        private System.Windows.Forms.ComboBox ProNameCb;
        private System.Windows.Forms.TextBox TPTb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ProQuanTb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox BillIdTb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label Billlbl;
        private System.Windows.Forms.Label Productlbl;
        private System.Windows.Forms.Label Customerlbl;
        private System.Windows.Forms.Button CrossBtn;
        private System.Windows.Forms.Button Addbtn;
        private System.Windows.Forms.Button ResetBtn;
        private System.Windows.Forms.TextBox CusNameTb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox UPTb;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button Updatebtn;
        private System.Windows.Forms.Button Deletebtn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView BillDgv;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView ProductDgv;
    }
}