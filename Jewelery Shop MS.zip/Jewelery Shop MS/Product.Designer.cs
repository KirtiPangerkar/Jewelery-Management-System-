﻿namespace Jewelery_Shop_MS
{
    partial class Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Product));
            this.panel3 = new System.Windows.Forms.Panel();
            this.ProCatCb = new System.Windows.Forms.ComboBox();
            this.ProNameCb = new System.Windows.Forms.ComboBox();
            this.UPTb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ProQuanTb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ProIdTb = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.Billlbl = new System.Windows.Forms.Label();
            this.Productlbl = new System.Windows.Forms.Label();
            this.Customerlbl = new System.Windows.Forms.Label();
            this.Addbtn = new System.Windows.Forms.Button();
            this.Update_btn = new System.Windows.Forms.Button();
            this.DelBtn = new System.Windows.Forms.Button();
            this.ResetBtn = new System.Windows.Forms.Button();
            this.CrossBtn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ProductDgv = new System.Windows.Forms.DataGridView();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ProductDgv)).BeginInit();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel3.Controls.Add(this.ProCatCb);
            this.panel3.Controls.Add(this.ProNameCb);
            this.panel3.Controls.Add(this.UPTb);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.ProQuanTb);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.ProIdTb);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(0, -20);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(314, 706);
            this.panel3.TabIndex = 12;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // ProCatCb
            // 
            this.ProCatCb.FormattingEnabled = true;
            this.ProCatCb.Items.AddRange(new object[] {
            "wedding and Bridal Jewelery",
            "Pearl Jewelery",
            "Fashion Jewelery",
            "Men\'s Jewelery",
            "Antique and Vintage Jewelery",
            "Ethic and Cultural Jewelery"});
            this.ProCatCb.Location = new System.Drawing.Point(12, 351);
            this.ProCatCb.Name = "ProCatCb";
            this.ProCatCb.Size = new System.Drawing.Size(227, 24);
            this.ProCatCb.TabIndex = 27;
            // 
            // ProNameCb
            // 
            this.ProNameCb.FormattingEnabled = true;
            this.ProNameCb.Items.AddRange(new object[] {
            "Diamond Engagement Ring",
            "Pearl Necklase",
            "Statement Earrings",
            "Men\'s Leather Bracelet",
            "Vintage Brooch",
            "Ethic Beaded Necklace"});
            this.ProNameCb.Location = new System.Drawing.Point(12, 239);
            this.ProNameCb.Name = "ProNameCb";
            this.ProNameCb.Size = new System.Drawing.Size(227, 24);
            this.ProNameCb.TabIndex = 26;
            // 
            // UPTb
            // 
            this.UPTb.Location = new System.Drawing.Point(12, 578);
            this.UPTb.Name = "UPTb";
            this.UPTb.Size = new System.Drawing.Size(227, 22);
            this.UPTb.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(12, 544);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 31);
            this.label3.TabIndex = 21;
            this.label3.Text = "Unit Price";
            // 
            // ProQuanTb
            // 
            this.ProQuanTb.Location = new System.Drawing.Point(16, 464);
            this.ProQuanTb.Name = "ProQuanTb";
            this.ProQuanTb.Size = new System.Drawing.Size(227, 22);
            this.ProQuanTb.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(3, 430);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(287, 31);
            this.label2.TabIndex = 19;
            this.label2.Text = "Product Quantity";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(3, 317);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(297, 31);
            this.label9.TabIndex = 17;
            this.label9.Text = "Product Category";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(6, 205);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(226, 31);
            this.label8.TabIndex = 16;
            this.label8.Text = "Product Name";
            // 
            // ProIdTb
            // 
            this.ProIdTb.Location = new System.Drawing.Point(12, 136);
            this.ProIdTb.Name = "ProIdTb";
            this.ProIdTb.Size = new System.Drawing.Size(227, 22);
            this.ProIdTb.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(10, 102);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(183, 31);
            this.label6.TabIndex = 13;
            this.label6.Text = "Product  Id";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(40, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(139, 31);
            this.label7.TabIndex = 14;
            this.label7.Text = "Product";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(652, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(256, 31);
            this.label1.TabIndex = 19;
            this.label1.Text = "JEWELLERY SHOP";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gray;
            this.panel4.Controls.Add(this.button1);
            this.panel4.Controls.Add(this.Billlbl);
            this.panel4.Controls.Add(this.Productlbl);
            this.panel4.Controls.Add(this.Customerlbl);
            this.panel4.Location = new System.Drawing.Point(320, 61);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(963, 64);
            this.panel4.TabIndex = 20;
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(888, 11);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(44, 41);
            this.button1.TabIndex = 17;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Billlbl
            // 
            this.Billlbl.AutoSize = true;
            this.Billlbl.BackColor = System.Drawing.Color.Crimson;
            this.Billlbl.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Billlbl.ForeColor = System.Drawing.Color.Black;
            this.Billlbl.Location = new System.Drawing.Point(652, 15);
            this.Billlbl.Name = "Billlbl";
            this.Billlbl.Size = new System.Drawing.Size(75, 31);
            this.Billlbl.TabIndex = 13;
            this.Billlbl.Text = "Bill";
            this.Billlbl.Click += new System.EventHandler(this.Billlbl_Click);
            // 
            // Productlbl
            // 
            this.Productlbl.AutoSize = true;
            this.Productlbl.BackColor = System.Drawing.Color.Crimson;
            this.Productlbl.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Productlbl.ForeColor = System.Drawing.Color.Black;
            this.Productlbl.Location = new System.Drawing.Point(332, 15);
            this.Productlbl.Name = "Productlbl";
            this.Productlbl.Size = new System.Drawing.Size(139, 31);
            this.Productlbl.TabIndex = 12;
            this.Productlbl.Text = "Product";
            // 
            // Customerlbl
            // 
            this.Customerlbl.AutoSize = true;
            this.Customerlbl.BackColor = System.Drawing.Color.Crimson;
            this.Customerlbl.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Customerlbl.ForeColor = System.Drawing.Color.Black;
            this.Customerlbl.Location = new System.Drawing.Point(13, 15);
            this.Customerlbl.Name = "Customerlbl";
            this.Customerlbl.Size = new System.Drawing.Size(159, 31);
            this.Customerlbl.TabIndex = 12;
            this.Customerlbl.Text = "Customer";
            this.Customerlbl.Click += new System.EventHandler(this.Customerlbl_Click);
            // 
            // Addbtn
            // 
            this.Addbtn.BackColor = System.Drawing.Color.White;
            this.Addbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addbtn.Font = new System.Drawing.Font("Mongolian Baiti", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addbtn.ForeColor = System.Drawing.Color.Black;
            this.Addbtn.Location = new System.Drawing.Point(415, 513);
            this.Addbtn.Name = "Addbtn";
            this.Addbtn.Size = new System.Drawing.Size(129, 31);
            this.Addbtn.TabIndex = 21;
            this.Addbtn.Text = "Add";
            this.Addbtn.UseVisualStyleBackColor = false;
            this.Addbtn.Click += new System.EventHandler(this.LogBtn_Click);
            // 
            // Update_btn
            // 
            this.Update_btn.BackColor = System.Drawing.Color.White;
            this.Update_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Update_btn.Font = new System.Drawing.Font("Mongolian Baiti", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Update_btn.Location = new System.Drawing.Point(615, 513);
            this.Update_btn.Name = "Update_btn";
            this.Update_btn.Size = new System.Drawing.Size(113, 31);
            this.Update_btn.TabIndex = 22;
            this.Update_btn.Text = "Update";
            this.Update_btn.UseVisualStyleBackColor = false;
            this.Update_btn.Click += new System.EventHandler(this.Update_btn_Click);
            // 
            // DelBtn
            // 
            this.DelBtn.BackColor = System.Drawing.Color.White;
            this.DelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DelBtn.Font = new System.Drawing.Font("Mongolian Baiti", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DelBtn.ForeColor = System.Drawing.Color.Black;
            this.DelBtn.Location = new System.Drawing.Point(810, 513);
            this.DelBtn.Name = "DelBtn";
            this.DelBtn.Size = new System.Drawing.Size(108, 31);
            this.DelBtn.TabIndex = 23;
            this.DelBtn.Text = "Delete";
            this.DelBtn.UseVisualStyleBackColor = false;
            this.DelBtn.Click += new System.EventHandler(this.DelBtn_Click);
            // 
            // ResetBtn
            // 
            this.ResetBtn.BackColor = System.Drawing.Color.White;
            this.ResetBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ResetBtn.Font = new System.Drawing.Font("Mongolian Baiti", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResetBtn.ForeColor = System.Drawing.Color.Black;
            this.ResetBtn.Location = new System.Drawing.Point(994, 513);
            this.ResetBtn.Name = "ResetBtn";
            this.ResetBtn.Size = new System.Drawing.Size(108, 31);
            this.ResetBtn.TabIndex = 24;
            this.ResetBtn.Text = "Reset";
            this.ResetBtn.UseVisualStyleBackColor = false;
            this.ResetBtn.Click += new System.EventHandler(this.ResetBtn_Click);
            // 
            // CrossBtn
            // 
            this.CrossBtn.BackColor = System.Drawing.Color.DarkGray;
            this.CrossBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CrossBtn.Font = new System.Drawing.Font("Algerian", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CrossBtn.Location = new System.Drawing.Point(1246, 1);
            this.CrossBtn.Name = "CrossBtn";
            this.CrossBtn.Size = new System.Drawing.Size(37, 29);
            this.CrossBtn.TabIndex = 25;
            this.CrossBtn.Text = "X";
            this.CrossBtn.UseVisualStyleBackColor = false;
            this.CrossBtn.Click += new System.EventHandler(this.CrossBtn_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.ProductDgv);
            this.panel1.Location = new System.Drawing.Point(365, 165);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(795, 312);
            this.panel1.TabIndex = 26;
            // 
            // ProductDgv
            // 
            this.ProductDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ProductDgv.Location = new System.Drawing.Point(17, 13);
            this.ProductDgv.Name = "ProductDgv";
            this.ProductDgv.RowHeadersWidth = 51;
            this.ProductDgv.RowTemplate.Height = 24;
            this.ProductDgv.Size = new System.Drawing.Size(761, 288);
            this.ProductDgv.TabIndex = 0;
            this.ProductDgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ProductDgv_CellClick);
            this.ProductDgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ProductDgv_CellContentClick_1);
            // 
            // Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(1283, 664);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.CrossBtn);
            this.Controls.Add(this.ResetBtn);
            this.Controls.Add(this.DelBtn);
            this.Controls.Add(this.Update_btn);
            this.Controls.Add(this.Addbtn);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Product";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product";
            this.Load += new System.EventHandler(this.Product_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ProductDgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox ProIdTb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label Billlbl;
        private System.Windows.Forms.Label Productlbl;
        private System.Windows.Forms.Label Customerlbl;
        private System.Windows.Forms.Button Addbtn;
        private System.Windows.Forms.Button Update_btn;
        private System.Windows.Forms.Button DelBtn;
        private System.Windows.Forms.Button ResetBtn;
        private System.Windows.Forms.Button CrossBtn;
        private System.Windows.Forms.ComboBox ProCatCb;
        private System.Windows.Forms.ComboBox ProNameCb;
        private System.Windows.Forms.TextBox UPTb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ProQuanTb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView ProductDgv;
    }
}